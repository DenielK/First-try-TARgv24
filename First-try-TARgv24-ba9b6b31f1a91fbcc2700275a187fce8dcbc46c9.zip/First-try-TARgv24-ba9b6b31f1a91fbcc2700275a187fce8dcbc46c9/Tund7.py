﻿from Tund7module import *
# a=int(input("Sisesta arv1:"))
# b=int(input("Sisesta arv2:"))
# c=input("Sisesta arv3:")

# vastus=summa3(a,b,int(c))
# print(vastus)

# #1
# from Tund7module import arithmetic00
# a=int(input("Sisesta arv1:"))
# b=int(input("Sisesta arv2:"))
# t=input("Sisesta opperation:(+,-,*,/) = ")

# vastus1=arithmetic(a,b,t)
# print(vastus1)

#2
# from Tund7module import is_year_leap
# v=int(input("Sisesta aasta:"))
# vastus2=is_year_leap(v)
# print(vastus2)

#3
# a=float(input("Sisesta numbri:"))
# vastus3=square_text(a)
# print(vastus3)

#4
month=float(input("Sisesta kuu number:"))
vastus4=season(month)
print(vastus4)

#5
a=float(input("Sisesta eurot:"))
years=int(input("Sisesta aastas:"))
vastus5=bank(a, years)
print(vastus5)

#6
